function [X, bet] = sample_pi( Q,sigma, B, beta_mean)
%%
%   Simple Gaussian distribution
%   
%%


L = chol(Q)';

bet = beta_mean  + 0.01*randn(size(B,2),1);
X = B*bet + sigma*(L'\randn(length(L),1));