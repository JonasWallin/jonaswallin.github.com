function [lik, dX] = likelihood_AR(x, beta, Q, sigma, B, beta_mean, neg)
%%
%   Simple Gaussian distribution
%   
%%
if nargin < 7
    neg = 0;
end



x_ = (x -B*beta);
Qx = Q*x_;
lik = - x_'*Qx/(2*sigma^2) - (beta-beta_mean)'*(beta-beta_mean)/(2*0.01^2);
dX = - Qx/(2*sigma^2);
dbeta = B'*Qx/(sigma^2) - (beta-beta_mean)/(0.01^2);
dX = [dbeta;dX];
if neg
   lik = -lik;
   dX = -dX;
    
end