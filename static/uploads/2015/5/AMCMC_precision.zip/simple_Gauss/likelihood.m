function [lik, dX] = likelihood(x, Q)
%%
%   Simple Gaussian distribution
%   
%%



Qx = Q*x;
lik = - (x'*Qx)/(2);
dX = - Qx/(2);
