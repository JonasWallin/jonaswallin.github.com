clearvars
close all
rng(12341)
% grid points
n_s = [20];%30;
n_obs = 100;
% how often to sample the eigenvalue chara
sample_b = 1000;

% number simulation and burin
sim = 10^5;
burnin = 10^4;
version = [1,2,1,2];
bs = cell(length(version), length(n_s));
time_method = zeros(length(version),2, length(n_s));
   
for k = 1:length(n_s)
    n = n_s(k);
    %%
    %   Setting up the Gaussian covariance and likelihood
    %%
    sigma_eps = 0.1;
    [loc, Qp] = build_Q(n);
    n_ = length(Qp);
    A = speye(n_);
    A = A(randsample(n_,n_obs),:);
    Qs = Qp + A'*A/sigma_eps^2;
    lik = @(x) likelihood(x, Qs);  

    % view the field if you want
    %L = chol(Qs)';
    %X = L'\randn(length(L),1);
    %imagesc(reshape(X,n,n))


    
    sigma_MH  = 0.02;
    Sigma_T = full(inv(Qs));
     for j = 1:length(version)
        X = zeros(length(Qs),1);

        L = cell(2,1);
        L{1} = lik;
        L{2} = X;
        if j >= 2
            opts = AMCMC_MH_prec_init(L,sigma_MH,1,version(j),1);
        else
            opts = AMCMC_MH_prec_init(L,sigma_MH,0,version(j),1);
        end
        opts{5}.burnin = burnin;
        opts{5}.batch = 5;
        opts{5}.count_2 = 2;
        Q_ = speye(length(X));
        for i=1:sim
            if i== burnin
                opts{6}.count = 1;
                %opts{2} =  Chol_init_fromData(opts{8}, X_vec(burnin/2:5:(burnin-1),opts{4}));
            end
            tic
            [opts] = AMCMC_MH_prec_sample(opts);
            time_method(j,1,k) = toc +  time_method(j,1,k);
            time_temp(1) = toc;
            lik_old = opts{5}.lik_old;
            [opts]  = AMCMC_MH_RR(opts);
            tic
             [opts,L]=AMCMC_MH_prec(opts);
             time_method(j,2,k) = toc +  time_method(j,2,k);
             time_temp(2) = toc;
             
            if  mod(i,sample_b)==0 
                if version(j)==1
                   e= eig(full((opts{3}*opts{3}')*Qs));

                   b = length(X)*sum(1./e)/(sum(sqrt(1./e)))^2;
                   %b = norm(full(inv(opts{3}*opts{3}')-Qs)); 
                else
                    
                    Q_ = speye(length(X));
                    Q_( opts{4}, opts{4}) = opts{3}*opts{3}';
                    e= eig(full(Sigma_T*Q_) ); 
                    b = length(X)*sum(e)/(sum(sqrt(e)))^2;
                    %b = norm(full(Q_-Qs));
                end
                 bs{j,k}=[bs{j,k};b];
                 fprintf('i=%d, time= (%.4f,%.4f), b = %.1f\n',i,time_temp(1),time_temp(2),b);
            end
        end

     end
end
%save('Gaussian_grid4.mat','bs','time_method');
plot(sample_b*(1:length(bs{2,1}))',bs{1,1})
hold on
plot(sample_b*(1:length(bs{2,1}))',bs{2,1},'r--')
plot(sample_b*(1:length(bs{3,1}))',bs{3,1},'k--')
plot(sample_b*(1:length(bs{4,1}))',bs{4,1},'g--')
xlabel('iteration')
ylabel('b')
tightfig()