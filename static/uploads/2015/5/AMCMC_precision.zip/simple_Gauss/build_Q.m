function [loc, Qs] = build_Q(n)
%%
% building precision matrix using FEM 
%%

range = 0.1; 
x_ = linspace(0,1,n);
[X_g, Y_g]  = meshgrid(x_,x_);
loc = [X_g(:) Y_g(:)];

h = (x_(2)-x_(1))^2;
kappa2 = 8/range^2;
tau = 1/(40*0.1*4*pi*kappa2);
C    = speye(n*n) * h; %area of rectangle round each point
Cinv = speye(n*n) / h;
G1 = -spdiags(ones(n+1,2),[-1 1],n,n);
G2 = -spdiags(ones(n+1,2),[-1 1],n,n);
G = kron(G1,speye(n)) + kron(speye(n),G2);
G = G - spdiags(sum(G,2),0,n*n,n*n);
G = G / h;


K = G + kappa2*C;
Qs = tau*K' *  Cinv*K; 

