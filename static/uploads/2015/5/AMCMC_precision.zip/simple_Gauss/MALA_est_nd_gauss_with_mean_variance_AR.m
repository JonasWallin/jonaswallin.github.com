%%%%%%%%%%%%%%%%
%%
%%  Trying to estimate the cholesky factor of the precision
%%  nxn Gaussian processes
%%
%%
%%%%%%%%%%%%%%%%
close all
clearvars
addpath ../AMCMC/
addpath ../AMCMC/mex/
addpath ../AMCMC/analysis/
n =100;
count = 1;
acc_vec = 0;
sim = 10^4;
burnin = 10^3;
sigma_MH  = 10^-2/(n+2)^(0.05);
sigma = 0.5;
version = [2,1]; % 1 regular Sigma estimation
            % 2 precision estimation    

            
Qs = sparse(toeplitz([2.1,0.5, -0.3,zeros(1,n-3)]'));
B = [ones(n,1), rand(n,1)];
  lik = @(x) likelihood_AR(x(3:end),x(1:2), Qs,sigma,B ,[1;0]);       
%    lik = @(x) likelihood(x(1:end-2), Qs,0.1,B, x(end-1:end),[1;0]);       

time_method = zeros(length(version),1);

X = zeros(n+2,1);
X_vec = zeros(sim,length(X));
lik_vec = zeros(sim,1);
 for i=1:sim
  [Xs, beta] = sample_pi( Qs, sigma, B , [1;0]);
  X_vec(i,:) = [beta;Xs]';
    lik_vec(i) = lik(X_vec(i,:)');
 end
     figure(1)
    subplot(length(version)+1 ,1 ,length(version)+1)
    plot(X_vec)
    ax_1 = [1 sim, min(min(X_vec(:,1:length(Qs)))) max(max(X_vec(:,1:length(Qs))))];
    axis(ax_1)

    figure(2)
    subplot(length(version)+1 ,1 ,length(version)+1)
    plot(lik_vec(5000:end))
Sigmas = cell(3,1);
Sigmas{3} = cov(X_vec);
Xstart = X_vec(end,:)';
X_vecs= cell(length(version),1);
 for j = 1:length(version)
    X = Xstart;
    
    L = cell(2,1);
    L{1} = lik;
    L{2} = X;
    opts = AMCMC_MH_prec_init(L, sigma_MH,1,version(j));
    opts{5}.burnin = burnin;
    



    L = speye(length(X)); 
    X_m = zeros(length(X),1);
    acc =zeros(sim,1);
    X_vec = zeros(sim,length(X));
    lik_vec = zeros(sim,1);
    tic
    for i=1:sim
        
        [opts, acc(i)] = AMCMC_MH_prec_sample(opts);
        X = opts{5}.X;
        lik_old = opts{5}.lik_old;
        [opts]  = AMCMC_MH_RR(opts);
         [opts,L]=AMCMC_MH_prec(X,opts);
        lik_vec(i) = lik_old;
        X_vec(i,:) = X;
    end
    time_method(j) = toc;
    mean(acc)
    X_vecs{j} = X_vec;
    figure(1)
    subplot(length(version)+1,1,j)
    plot(X_vec)
    axis(ax_1)
    figure(2)
    subplot(length(version)+1,1,j)
    plot(lik_vec(5000:end))
    Sigmas{j} = cov(X_vec);
 end
figure(3)
plot(diag(Sigmas{3})-diag(Sigmas{2}),'.')
hold on
plot(diag(Sigmas{3})-diag(Sigmas{1}),'rx')

figure(4)
corrs = zeros(length(X),length(version));
for j = 1:length(version)
    fprintf('method %d took %.2f sec\n',j, time_method(j));
   for i=1:length(X)
       subplot(length(version),1,j)
       Xtemp = X_vecs{j}(burnin:end,i);
       [xc,lags] = xcorr(Xtemp(1:1:end)-mean(Xtemp(1:1:end)),200,'coeff');
       plot(lags(lags>=0),xc(lags>=0),'r') 
       corrs(i,j) = xc(lags==5);
       hold on
   end
end
figure()
plot(corrs(:,1),'o')
hold on
plot(corrs(:,2),'rx')