%%%%%%%%%%%%%%%%
%%
%%  Trying to estimate the cholesky factor of the precision
%%  nxn Gaussian processes
%%
%%
%%%%%%%%%%%%%%%%
close all
clearvars
addpath ../AMCMC/
addpath ../AMCMC/mex/
addpath ../AMCMC/analysis/

count = 1;
acc_vec =40;
sim = 2*10^4;
burnin = 10^4;
sigma_MH  = 0.002;
sigma = 0.5;
rng(123451)
version = [2]; % 1 regular Sigma estimation
            % 2 precision estimation    

G = mread('G.mtx');
n  = length(G);
C = mread('C.mtx');
kappa2 = 0.6;
Ci = sparse(1:n,1:n,1./sum(C,2));
C = sparse(1:n,1:n,sum(C,2));   
K = ((C * kappa2) + G);
Qs = (K*Ci*K)/sigma^2;

%Qs = Qs(1:300,1:300);%
%Qs = Qs(1:500,1:500);
n = length(Qs);
%Qs = Qs + sparse(1:n,1:n,1+10*rand(n,1));
lik = @(x) likelihood(x, Qs);       
%    lik = @(x) likelihood(x(1:end-2), Qs,0.1,B, x(end-1:end),[1;0]);       
Sigma_T = full(inv(Qs));
time_method = zeros(length(version),1);

X = zeros(n,1);
X_vec = zeros(sim,length(X));
lik_vec = zeros(sim,1);

Xstart = X_vec(end,:)';
L = chol(Qs)';
 for i=1:sim
    X_vec(i,:) = L'\randn(length(L),1);
    lik_vec(i) = lik(X_vec(i,:)');
 end
 ax_lim = [min(X_vec(:))*0.8,max(X_vec(:))*0.8];
 figure(4)
 subplot(211)
 plot(X_vec)
 ylim(ax_lim)
 subplot(212)
 plot(lik_vec)
bs = cell(length(version),1);
Ls = cell(length(version),1);
X_vecs = cell(length(version),1);

L_true = full(chol(inv(Qs))');
 for j = 1:length(version)
    X = Xstart;
    
    L = cell(2,1);
    L{1} = lik;
    L{2} = X;
    opts = AMCMC_MH_prec_init(L, sigma_MH,1,version(j),1);
    opts{5}.burnin = burnin;
    opts{5}.batch = 20;
    opts{6}.batch = 25;
    
    X_m = zeros(length(X),1);
    acc =zeros(sim,1);
    X_vec = zeros(sim,length(X));
    lik_vec = zeros(sim,1);
    tic
    for i=1:sim
        if i== burnin
            opts{6}.count = 1;
            opts{5}.batch = 2;
        end
        [opts, acc(i)] = AMCMC_MH_prec_sample(opts);
        X = opts{5}.X;
        lik_old = opts{5}.lik_old;
        [opts]  = AMCMC_MH_RR(opts);
         [opts,L]=AMCMC_MH_prec(X,opts);
        lik_vec(i) = lik_old;
        X_vec(i,:) = X;
        if  mod(i,1000)==0 
            fprintf('i=%d\n',i);
            if version(j)==1
               e= eig(full((opts{3}*opts{3}')*Qs));
                
               b = length(X)*sum(1./e)/(sum(sqrt(1./e)))^2;
               %b = norm(full(inv(opts{3}*opts{3}')-Qs)); 
            else
                Q_( opts{4}, opts{4}) = opts{3}*opts{3}';
                e= eig(full(Sigma_T*Q_) ); 
                b = length(X)*sum(e)/(sum(sqrt(e)))^2;
                %b = norm(full(Q_-Qs));
            end
             bs{j}=[bs{j};b];
        end
    end
    time_method(j) = toc;
    mean(acc)
    
    figure(1)
    subplot(length(version),1,j)
    plot(X_vec)
 ylim(ax_lim)
    figure(2)
    subplot(length(version),1,j)
    plot(lik_vec(1:end))
    figure(3)
    subplot(length(version),1,j)
    plot(bs{j})
    Ls{j} = opts{3};
    figure(5)
    hist(X_vec(:,10),200)
    X_vecs{j} = X_vec;
  %  figure(7)
  %  subplot(length(version),2,j)
  %  plot( X_vec(:,150))
 %ylim(ax_lim)
 %   subplot(length(version),2,j+length(version))
 %   [xc,lags] = xcorr(X_vec(1:10:end,150)-mean(X_vec(:,150)),400,'coeff');
 %   plot(lags(lags>=0),xc(lags>=0),'r')   
    
    
 end
 
 
figure()
corrs = zeros(length(X),length(version));
for j = 1:length(version)
    fprintf('method %d took %.2f sec\n',j, time_method(j));
   for i=1:length(X)
       subplot(length(version),1,j)
       Xtemp = X_vecs{j}(burnin:10:end,i);
       [xc,lags] = xcorr(Xtemp(1:1:end)-mean(Xtemp(1:1:end)),200,'coeff');
       plot(lags(lags>=0),xc(lags>=0),'r') 
       corrs(i,j) = xc(lags==2);
       hold on
   end
end
%figure()
%plot(corrs(:,1),'o')
%hold on
%plot(corrs(:,2),'rx')