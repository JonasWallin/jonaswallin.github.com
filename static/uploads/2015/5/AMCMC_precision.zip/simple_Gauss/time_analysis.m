close all

load('Gaussian_grid4.mat');
 time_method_4 = time_method/10^7;
 load('Gaussian_grid.mat');
 time_method_3 = time_method(:,:,1)/10^7;
 load('Gaussian_grid2.mat');
 time_method_2 = time_method(:,:,1)/10^6;
 load('Gaussian_grid3.mat');
 time_method_1 = time_method(:,:,1)/10^6;
 
 Sampling_prec = [
     time_method_1(2,1);
     time_method_2(2,1);
     time_method_3(2,1);
     time_method_4(2,1);
 ]
 Sampling_sigma = [
     time_method_1(1,1);
     time_method_2(1,1);
     time_method_3(1,1);
     time_method_4(1,1);
 ]
 adapt_prec = [
     time_method_1(2,2);
     time_method_2(2,2);
     time_method_3(2,2);
     time_method_4(2,2);
 ]
 adapt_sigma = [
     time_method_1(1,2);
     time_method_2(1,2);
     time_method_3(1,2);
     time_method_4(1,2);
 ]

plot([10^2,20^2,30^2,40^2]',adapt_sigma)
hold on

plot([10^2,20^2,30^2,40^2]',adapt_prec,'r--')
plot([10^2,20^2,30^2,40^2]',Sampling_prec,'r.--')
plot([10^2,20^2,30^2,40^2]',Sampling_sigma,'.-')
tightfig()