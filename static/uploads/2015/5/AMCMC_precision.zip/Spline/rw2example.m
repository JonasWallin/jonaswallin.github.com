close all
clearvars
addpath(genpath('../AMCMC/'))
sim = 10^4;
sigma_MH =  0.005;
burnin = 10^3;
burnin2 = 5*10^3;
rng(1)
n = 100;
nobs = 1000;
x = linspace(0,1,n);
versions = [1,2];
load_covariance = 0; %used to verfiy Q sparse actually works

R = rw2prec(x);
tau = 0.01;
Q = tau*R;

X = chol(speye(n)*1e-3 + Q)\randn(n,1);


loc = rand(nobs,1)*max(x);
A = rw2A(x,loc);

tau_phi = 0.001;
Qphi = tau_phi*R;
phi = chol(speye(n)*1e-3 + Q)\randn(n,1);
sigma = 0.1 + exp(A*phi)/max(exp(A*phi));
sigma_plot = 0.1 + exp(phi)/max(exp(phi));

Y = A*X + sigma.*randn(nobs,1);
X_true = X;

figure(1);clf
plot(loc,Y,'k.');
hold on
plot(x,X,'LineWidth',2)
plot(x,X+sigma_plot,'r','LineWidth',2);
plot(x,X-sigma_plot,'r','LineWidth',2);
plot(x,X+2*sigma_plot,'r--','LineWidth',1);
plot(x,X-2*sigma_plot,'r--','LineWidth',1);

X_vecs = cell(length(versions),1);
time_method = zeros(length(versions),1);
lik_vecs  = cell(length(versions),1);
Sigmas =cell(length(versions),2);
for j = 1:length(versions)

    [X] = sample_X(Y, zeros(length(X_true),1), A, Q, exp([-3;-3]));
    lik = @(X)  likelihood(X, Y, A, Q);
    X =  [zeros(length(X),1);X;-3;-3];
    L{1} = lik;
    L{2} = X;
    opts_MH = AMCMC_MH_prec_init(L,sigma_MH,1,versions(j),1);
    opts_MH{5}.burnin = burnin;
    opts_MH{5}.batch = 5;
    opts_MH{6}.batch = 50;
    opts_MH{6}.accepantce_rate = 0.55;
    if versions(j)==1 && load_covariance==1
       load('Sigmas_rw2.mat');
       opts_MH{3} = chol(Sigmas{2, 1})';
       opts_MH{8} =opts_MH{3};
       opts_MH{5}.count_2  = Sigmas{2, 2}/10;
    end
    
    acc = zeros(sim,1);
    X_vec = zeros(sim,length(L{2}));
    lik_vec = zeros(sim,1);
    tic
    for i=1:sim
        [opts_MH, acc(i)] = AMCMC_MH_prec_sample(opts_MH );
        X = opts_MH{5}.X;
       lik_old = opts_MH{5}.lik_old;
       lik_vec(i) = lik_old;
       X_vec(i,:) = X;
       [opts_MH]  = AMCMC_MH_RR(opts_MH);
       [opts_MH,L]=AMCMC_MH_prec(opts_MH);
       if mod(i,100)==0 
                fprintf('iter = %d (%.2e)\n',i, opts_MH{5}.sigma_MH);
       end
    end
    time_method(j) = toc;
    X_vecs{j} = X_vec;
    lik_vecs{j} = lik_vec;
    if versions(j) == 1
        Sigmas{j, 1} = opts_MH{3} * opts_MH{3}';
        Sigmas{j, 2} = opts_MH{5}.count;
    else
        Q_( opts_MH{4}, opts_MH{4}) = opts_MH{3}*opts_MH{3}';
        Sigmas{j, 1} = full(inv(Q_));
        Sigmas{j, 2} = opts_MH{5}.count;
    end
end

figure()
corrs = zeros(length(X),length(versions));
for j = 1:length(versions)
    fprintf('method %d took %.2f sec\n',j, time_method(j));
   for i=1:length(X)
       subplot(length(versions),1,j)
       Xtemp = X_vecs{j}(4*burnin2:end,i);
       [xc,lags] = xcorr(Xtemp(1:10:end)-mean(Xtemp(1:10:end)),200,'coeff');
       plot(lags(lags>=0),xc(lags>=0),'r') 
       corrs(i,j) = xc(lags==5);
       hold on
   end
end
figure(3)
plot(lik_vecs{2}(burnin:end),'r-')
hold on
plot(lik_vecs{1}(burnin:end),'-')


figure(4)

plot(corrs(:,2),'rx')
hold on

plot(corrs(:,1),'o')
if 0
    figure()
    plot(lik_vec(burnin:end))

    [n m ] =size(A);
    figure()
    subplot(311)
    plot(exp(X(1:m)))
    hold on
    plot(sigma_plot,'r--')
    plot(mean(exp(X_vec(burnin:100:end,1:m)))','g--')
    subplot(312)
    plot(X((m+1):end-2))
    hold on
    plot(X_true,'r--')
    subplot(313)
    plot((A*X_vec(1:100:end,(m+1):end-2)')')
    figure()
    plot(loc,Y,'k.');
    hold on
    plot(x,X((m+1):end-2),'LineWidth',2)
    figure()
    plot(X_vec(1:100:end,end-1:end));

    figure()
    plot(X_vec(:,1:100))
end
 [n m ] =size(A);
 figure()
 subplot(211)
 plot(X_vecs{1}(1:10:end,(m+20):m+22))
 subplot(212)
    plot(X_vecs{2}(1:10:end,(m+20):m+22))
    
 save('Sigmas_rw2.mat','Sigmas')