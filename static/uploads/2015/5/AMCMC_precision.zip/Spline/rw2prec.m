function R = rw2prec(x)
  n = length(x);
  d = [inf diff(x)];
  dm1 = [d(2:n) inf];
  dm2 = [d(3:n) inf inf ];
  d1 = [inf d(1:(n-1))];
  d2 = [inf inf d(1:(n-2))];

  Q=[2./(dm2.*dm1.*(dm2+dm1)); -(2./dm1.^2).*(1./dm2 + 1./d)]';
  R1 = spdiags(Q,[-2:-1],n,n);
  d0 = 2./(dm1.^2.*(dm2+dm1))+(2./(dm1.*d)).*(1./dm1+1./d)+2./(d.^2.*(d+d1));
  R0 = spdiags(d0',0,n,n);
  R = R1 + R0 + R1';
end
