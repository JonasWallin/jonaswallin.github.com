clearvars
close all
n = 100;
nobs = 1000;
x = linspace(0,1,n);

R = rw2prec(x);
tau = 0.01;
Q = tau*R;

X = chol(speye(n)*1e-3 + Q)\randn(n,1);


loc = rand(nobs,1)*max(x);
A = rw2A(x,loc);

tau_phi = 0.0001;
Qphi = tau_phi*R;
phi = chol(speye(n)*1e-3 + Q)\randn(n,1);
sigma = 0.1 + exp(A*phi)/max(exp(A*phi));
sigma_plot = 0.1 + exp(phi)/max(exp(phi));

Y = A*X + sigma.*randn(nobs,1);

XV = [X;phi;tau_phi;tau];
[lik, dX] = likelihood(XV, Y, A, Q);



ep = 10^-6;
dX_num = zeros(size(dX));
for i =1:length(XV)
    XV_ep = XV;
    XV_ep(i) = XV(i) + ep;
    [lik_ep, dX] = likelihood(XV_ep, Y, A, Q);
    dX_num(i) = (lik_ep - lik)/ep;
end
plot((dX_num-dX))