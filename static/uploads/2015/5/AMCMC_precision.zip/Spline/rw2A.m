function A = rw2A(x,loc)

  if(min(loc)< min(x) || max(loc) > max(x))
    disp('locations outside support of basis')
    return
  end

  nx = length(x);
  nloc = length(loc);
  i = [1:nloc; 1:nloc]';
  j = zeros(nloc,2);
  vals = ones(nloc,2);
  for ii=1:nloc
    j(ii,1) = sum(sum((loc(ii) - x)>=0));
    vals(ii,1) = loc(ii) - x(j(ii,1));
    j(ii,2) = j(ii,1) + 1;
    if(j(ii,2)<=nx)
      vals(ii,2) =  x(j(ii,2)) - loc(ii);
    else
        j(ii,2) = j(ii,2) -2;
    end
  end
  vals = 1-bsxfun(@rdivide,vals,sum(vals,2));
  A = sparse(i,j,vals, nloc,nx);
end
