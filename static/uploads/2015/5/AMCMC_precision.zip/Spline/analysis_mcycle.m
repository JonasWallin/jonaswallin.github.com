close all
clearvars
addpath(genpath('../AMCMC/'))
sim = 10^5;
save_fig = 0;
sigma_MH =  0.005;
burnin   = 10^3;
burnin2  = 2*10^3;
thin = 5;
rng(1)
n = 250;
dat =  load('times_acc.dat');
x = linspace(min(dat(:,1)),max(dat(:,1)),n);
versions = [2,1,1,2];
load_covariance = 0; %used to verfiy Q sparse actually works

R = rw2prec(x);
%tau = 0.01;
Q = R;


loc = dat(:,1);
Y   = dat(:,2);
A = rw2A(x,loc);


figure(1);clf
plot(dat(:,1), dat(:,2),'k.');

X_vecs = cell(length(versions),1);
time_method = zeros(length(versions),1);
lik_vecs  = cell(length(versions),1);
Sigmas =cell(length(versions),2);
for j = 1:length(versions)
    count = 1;
    [X] = sample_X(Y, zeros( size(A,2),1), A, Q, exp([-3;-3]));
    lik = @(X)  likelihood(X, Y, A, Q);
    X =  [zeros( size(A,2),1);X;-3;-3];
    L{1} = lik;
    L{2} = X;
    if j <= 2
        opts_MH = AMCMC_MH_prec_init(L,sigma_MH,1,versions(j),1);
        opts_MH{6}.accepantce_rate = 0.574;
    else
        opts_MH = AMCMC_MH_prec_init(L,sigma_MH,0,versions(j),1);
        opts_MH{6}.accepantce_rate = 0.234;
    end
    opts_MH{5}.burnin = burnin;
    opts_MH{5}.batch = 5;
    opts_MH{6}.batch = 50;
    
%     if versions(j)==1 && load_covariance==1
%        load('Sigmas_rw2.mat');
%        opts_MH{3} = chol(Sigmas{2, 1})';
%        opts_MH{8} =opts_MH{3};
%        opts_MH{5}.count_2  = Sigmas{2, 2}/10;
%     end
    
    acc = zeros(sim/thin,1);
    X_vec = zeros(sim/thin,length(L{2}));
    lik_vec = zeros(sim/thin,1);
    
    time_method(j) = 0;
    
    for i=1:sim
        tic
        [opts_MH, acc(i)] = AMCMC_MH_prec_sample(opts_MH );
        X = opts_MH{5}.X;
       lik_old = opts_MH{5}.lik_old;
       
       
       [opts_MH]  = AMCMC_MH_RR(opts_MH);
       [opts_MH,L]=AMCMC_MH_prec(opts_MH);
       if i > burnin2
            time_method(j) = time_method(j) + toc;
       end
       if mod(i,100)==0 
                fprintf('iter = %d (%.2e)\n',i, opts_MH{5}.sigma_MH);
       end
       if mod(i,thin)==0
          lik_vec(count) = lik_old;
          X_vec(count,:) = X;
          count = count + 1; 
       end
    end
   
    X_vecs{j} = X_vec;
    lik_vecs{j} = lik_vec;
end

figure()
corrs = zeros(length(X),length(versions));
for j = 1:length(versions)
    fprintf('method %d took %.2f sec\n',j, time_method(j));
   for i=1:length(X)
       subplot(length(versions),1,j)
       Xtemp = X_vecs{j}(4*burnin2/thin:end,i);
       [xc,lags] = xcorr(Xtemp(1:end)-mean(Xtemp(1:end)),200,'coeff');
       plot(lags(lags>=0),xc(lags>=0),'r') 
       corrs(i,j) = xc(lags==5);
       hold on
   end
end
figure(3)
plot(lik_vecs{2}(2*burnin/thin:end),'r-')
hold on
plot(lik_vecs{1}(2*burnin/thin:end),'.')
if length(versions) > 2
    plot(lik_vecs{3}(2*burnin/thin:end),'k--')
    plot(lik_vecs{4}(2*burnin/thin:end),'g--')
end
ylim([min(cell2mat(lik_vecs)), max(cell2mat(lik_vecs))])
tightfig()

figure(4)
plot(corrs(:,2),'rx')
hold on

plot(corrs(:,1),'o')
if length(versions) > 2
    plot(corrs(:,3),'ko')
    plot(corrs(:,4),'go')
end

 [n, m ] =size(A);
 
 [~,pos] = min(abs(loc-13.8));
 
  
for i =1:length(X_vecs)
    h = figure();
    plot(X_vecs{i}(1:sim/thin,pos))
    ylim([min(X_vecs{2}(1:end,(pos))), max(X_vecs{2}(1:end,(pos)))])
    tightfig()
    if save_fig
        fig_name=  sprintf('../../art/figs/Y_pos138_%d_%d',i,m);
        saveFigure(h,fig_name);
        print(fig_name,'-dpdf')
        print(fig_name,'-deps')
        close
    end
    
end
for i =1:length(X_vecs)
    h = figure();
    plot(X_vecs{i}(1:end,m+pos))
    ylim([min(X_vecs{2}(1:end,(m+pos))), max(X_vecs{2}(1:end,(m+pos)))])
    tightfig()
    if save_fig
        fig_name =  sprintf('../../art/figs/X_pos138_%d_%d',i,m);
        saveFigure(h,fig_name);
        print(fig_name,'-dpdf')
        print(fig_name,'-deps')
        close
    end
end

h = figure(1);
hold on
plot(x, mean(X_vec(burnin/thin:end,(m+1):end-2))','b-');
plot(x,  mean(X_vec(burnin/thin:end,(m+1):end-2))' + 1.96* mean(exp(X_vec(burnin/thin:end,1:m)))','r--');
plot(x,  mean(X_vec(burnin/thin:end,(m+1):end-2))' - 1.96* mean(exp(X_vec(burnin/thin:end,1:m)))','r--');
tightfig()

if save_fig
    fig_name =  sprintf('../../art/figs/data_ex2_%d',m);
    saveFigure(h,fig_name);
    print(fig_name,'-dpdf')
    print(fig_name,'-deps')
    close
end
    for i =1:length(X_vecs)
        h = figure();
        plot(X_vecs{i}(1:end,end-1));
        tightfig();
        if save_fig
            fig_name =  sprintf('../../art/figs/tau_x_%d_%d',i,m);
            saveFigure(h,fig_name);
            print(fig_name,'-dpdf')
            print(fig_name,'-deps')
            close
        end
    end

    for i =1:length(X_vecs)
        h = figure();
        plot(X_vecs{i}(1:end,end));
        tightfig();
        if save_fig
            fig_name =  sprintf('../../art/figs/tau_v_%d_%d',i,m);
            saveFigure(h,fig_name);
            print(fig_name,'-dpdf')
            print(fig_name,'-deps')
            close
        end
    end
