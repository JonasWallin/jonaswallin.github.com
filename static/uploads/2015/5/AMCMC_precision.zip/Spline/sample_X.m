function [X] = sample_X(Y, V, A, Q, tau)

[n m] = size(A);
DV = exp(-2*A*V);
Q_x = tau(2) * Q;

Q_post = Q_x + A'*sparse(1:n,1:n,DV,n,n)*A;
X = Q_post\(A'*sparse(1:n,1:n,DV,n,n)*Y);
%L = chol(Q_post)';
%X = X + L'\randn(m,1);