function [lik, dX] = likelihood(X, Y, A, Q, neg)
%%
%
%%
if nargin < 5
    neg = 0;
end

[n, m] = size(A);

V  = X(1:m);
X_ = X(m+1:end-2);
tau = exp(X(end-1:end));

O = ones(n,1);

OA = O'*A;
res  = (Y-A*X_);
res2 = res.^2;
DV = exp(-2*A*V);
res2_DV = res2.*DV;
lik = -(OA*V) - sum(res2_DV)/2;
QV = Q*V;
VQV = V'*QV;
lik = lik - tau(1) *VQV/2 + (m-2)*log(tau(1))/2;
QX = Q*X_;
XQX = X_'*QX;
lik = lik - tau(2) * XQX/2  + (m-2)*log(tau(2))/2;

lik = lik + sum(log(tau)); %correction for transformation
dtau  =[- VQV/2  + (m-2)/(2*tau(1)) ;
        - XQX/2  + (m-2)/(2*tau(2))];
dtau = tau.*(dtau + 1./tau); %correction for transformation
dV = -OA' + A'*res2_DV -  tau(1) * QV;
dX_ =   A'*(res.*DV) - tau(2) * QX;
dX = [dV;dX_;dtau ];


if neg
    lik = - lik;
    dX  = - dX;
end