function [Sigma]=AMCMC_MH_Sigma_init(n)
%%
%	AMCMC updating Sigma matrix (or chol of Sigma)
%
%   Sigma_i{2} - upper cholesky factor
%   Sigma_i{1} - number of samples used to build sigma
%%

Sigma = cell(2,1);
Sigma{2} = chol(eye(n));
Sigma{1} = 10;
