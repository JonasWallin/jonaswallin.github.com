function b = AMCMC_MH_analysis( Sigma, Q_p)
%%
%   method for mixing rate
%   Stupied way of computing it   
%
%   Sigma - true covariance
%   Q_p   - estimatd precision matrix
%
%%
[vec_sigma, lambda_sigma ] = eig(Sigma);
[vec_Q, lambda_Q   ] = eig(full(Q_p));
M = vec_Q * diag(sqrt(1./diag(lambda_Q))) * vec_Q' * vec_sigma*diag(sqrt(1./diag(lambda_sigma)))*vec_sigma'  ;
e = eig(M);
b = length(M) * sum(e.^(-2))/sum(e.^(-1))^2;