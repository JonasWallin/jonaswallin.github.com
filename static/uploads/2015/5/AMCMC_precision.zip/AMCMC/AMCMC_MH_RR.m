function [Lobj]  = AMCMC_MH_RR(Lobj)
%%
% adapting sigma from Roberts a Rosenthal
%    Lobj{5} - strcut
%   .useMALA    - using MALA
%   .sigma_MH   - sigma_MH multiplicative factor
%   .lik_old    - likelihood for X
%   .X          - current "parameters"
%
%   Lobj{6} - struct used for adapation of sigma_MH
%   .accepantce_rate - sought accpetence rate
%   .batch      see AMCMC_MH_RR
%   .delta_min  see AMCMC_MH_RR
%   .delta_rate see AMCMC_MH_RR
%   .acc_vec    see AMCMC_MH_RR
%   .count      see AMCMC_MH_RR
%
%%


[Lobj{5}.sigma_MH, Lobj{6}.count, Lobj{6}.acc_vec]  = AMCMC_RR(Lobj{5}.sigma_MH, Lobj{6}.acc_vec, Lobj{6}.count, ...
                                    Lobj{6}.batch,  Lobj{6}.accepantce_rate, ...
                                     Lobj{6}.delta_min,  Lobj{6}.delta_rate);