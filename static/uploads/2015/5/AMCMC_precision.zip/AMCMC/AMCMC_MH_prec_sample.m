function [Lobj, acc]= AMCMC_MH_prec_sample( Lobj)
%%
% sampling using Adaptive MCMC for cholesky of precision matrix
% and update X
%
%   Lobj{3}           - Cholesky factor
%   Lobj{4}           - reodering
%   Lobj{5}.useMALA   - using MALA
%   Lobj{5}.sigma_MH  - sigma_MH multiplicative factor
%   Lobj{5}.lik_old   - likelihood for X
%   Lobj{5}.X         - current "parameters"
%
%   Lobj{6}.X         - acc_vec
%   Lobj{7}           -  version - 2 sparse L (Cholesky factor) of Q
%                                  1 full R (Cholesky factor) of \Sigma
%
%%

if Lobj{7} == 2
    if Lobj{5}.useMALA == 0
       L   = Lobj{3}; 
       reo = Lobj{4};
       n = length(L);
       Xstar = zeros(n, 1);
       Xstar(reo) = Lobj{5}.X(reo) +  Lobj{5}.sigma_MH * (L'\randn(n,1));
       lik_star = Lobj{1}(Xstar);
       acc = 0;
       if(log(rand) < lik_star - Lobj{5}.lik_old)
           Lobj{5}.lik_old = lik_star;
           Lobj{5}.X = Xstar; 
           acc = 1;
           Lobj{6}.acc_vec = Lobj{6}.acc_vec + 1;
       end
    else
       L   = Lobj{3}; 
       reo = Lobj{4};
       X   = Lobj{5}.X;
       dX  = Lobj{5}.dX_old;
       sigma_MH= Lobj{5}.sigma_MH;
       n = length(L);
       g = dX;
       Lg = L\g(reo);
       %mu_old  =  X(reo) +sigma_MH^2/2*( L'\Lg);
       Xstar = zeros(n, 1);
       %Xstar(reo) = mu_old + sigma_MH * (L'\randn(n,1));
       Xstar(reo) = X(reo) + sigma_MH * ( (randn(n,1) + 0.5*sigma_MH*Lg)'/L)';
       [lik_star, dX_star] = Lobj{1}(Xstar);
       gs = dX_star;
       Lgs = L\gs(reo);
       %mu_star =  Xstar(reo) +sigma_MH^2/2*( L'\Lgs);

       acc = 0;
       %Lxs = (L'*(Xstar(reo) - mu_old) );
       %q_xs = - (Lxs'*Lxs)/(2*sigma_MH^2);
       %Lx  = (L'*(X(reo) - mu_star) );
       %q_x = - (Lx'*Lx)/(2*sigma_MH^2);
       q_x_m_xs = (X-Xstar)'*(gs+g)/2-(Lgs'*Lgs)*sigma_MH^2/8 + (Lg'*Lg)*sigma_MH^2/8;
       if(log(rand) < lik_star - Lobj{5}.lik_old + q_x_m_xs)
           Lobj{5}.lik_old = lik_star;
           Lobj{5}.X       = Xstar; 
           Lobj{5}.dX_old  = dX_star; 
           Lobj{6}.acc_vec = Lobj{6}.acc_vec + 1;
           acc = 1;
       end        

    end
else
    if Lobj{5}.useMALA == 0
       L   = Lobj{3}; 
       n = length(L);
       Xstar = Lobj{5}.X +  Lobj{5}.sigma_MH * (L*randn(n,1));
       lik_star = Lobj{1}(Xstar);
       acc = 0;
       if(log(rand) < lik_star - Lobj{5}.lik_old)
           Lobj{5}.lik_old = lik_star;
           Lobj{5}.X = Xstar; 
           acc = 1;
           Lobj{6}.acc_vec = Lobj{6}.acc_vec + 1;
       end    
    else
       L   = Lobj{3};
       X   = Lobj{5}.X;
       dX  = Lobj{5}.dX_old;
       sigma_MH= Lobj{5}.sigma_MH;
       n = length(L);
       g = dX;
       Lg = L'*g;
       %mu_old  =  X +sigma_MH^2/2*( L*(L'*dX));
       %mu_old = X +sigma_MH^2/2*( L*Lg);
       %Xstar = mu_old + sigma_MH * (L*randn(n,1));
       Xstar = X +  sigma_MH * (L * ( randn(n,1) + sigma_MH/2 * Lg));
       [lik_star, dX_star] = Lobj{1}(Xstar);
       %mu_star =  Xstar +sigma_MH^2/2*(  L*(L'*dX_star));
        gs = dX_star;
        Lgs = L'*gs;
       acc = 0;
       %Lxs = (L\(Xstar - mu_old) );
       %q_xs = - (Lxs'*Lxs)/(2*sigma_MH^2);
       %Lx  = (L\(X - mu_star) );
       %q_x = - (Lx'*Lx)/(2*sigma_MH^2);
       q_x_m_xs = ((X-Xstar)'*(gs+g))/2-(Lgs'*Lgs)*sigma_MH^2/8 + (Lg'*Lg)*sigma_MH^2/8;
       if(log(rand) < lik_star - Lobj{5}.lik_old + q_x_m_xs)
           Lobj{5}.lik_old = lik_star;
           Lobj{5}.X       = Xstar; 
           Lobj{5}.dX_old  = dX_star; 
           Lobj{6}.acc_vec = Lobj{6}.acc_vec + 1;
           acc = 1;
       end        

    end
    
end