function [sigma, count, acc_vec]  = AMCMC_RR(sigma, acc_vec, count, batch, accepantce_rate, delta_min, delta_rate)
%%
% adapting sigma from Roberts a Rosenthal
%
%
%%

if nargin < 4
    batch = 50;
end
if nargin < 5
    accepantce_rate = 0.234;
end
if nargin < 6
    delta_min =0.1;
end
if nargin < 7
    delta_rate = 1/3;
end

count = count +1;

if mod(count , batch) == 0
    delta = min(delta_min, count^(-delta_rate));
    if acc_vec/batch > accepantce_rate
       sigma = sigma * exp( delta);
    else
        sigma = sigma / exp( delta);
    end
    
    acc_vec = 0;  
end