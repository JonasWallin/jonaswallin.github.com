function [Sigma_i, L]=AMCMC_MH_Sigma(X, Sigma_i)
%%
%	AMCMC updating Sigma matrix (or chol of Sigma)
%
%   X  - (removed mean)
%   Sigma_i{1} - n_est
%   Sigma_i{2} - cholesky_factor
%%

n  = Sigma_i{1} + 1;
R =  Sigma_i{2};
w1= sqrt((n-1)/n);
w2 = sqrt(1/n);
Sigma_i{2} = cholupdate(w1* R, w2*X,'+');
L = Sigma_i{2}';
Sigma_i{1} = n;