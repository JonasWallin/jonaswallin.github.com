function Lupdate =  Chol_init_fromData(L, Xvec) 
%%
%   setups the objects needed for the cholesky updating
%   L  - (n x n) cholesky factor of the covariance!
%
%   Xvec - (n x sim) samples
%
%   Output:
%   Lupdate{1}  - number of elements in each row (excluding the diagonal)
%   Lupdate{2}  - the row index
%   Lupdate{3}  - the estimated values of \Sigma_{A_i,A_i}^{-1}
%   Lupdate{4}  - the estimated values of \Sigma_{A_i,i}
%   Lupdate{5}  - counts
%   Lupdate{6}  - the estimated values of \Sigma_{i,i} or residuals
%   Lupdate{7}  - the values of the rows of constructing L
%   Lupdate{8}  - for bulding L
%   Lupdate{9}  - the values of the D
%   Lupdate{10} - the rate
%
%%
Sigma = cov(Xvec);
[m, ~] = size(Xvec);
Mu = mean(Xvec)';
Lupdate =  Chol_init_fromCovMatrix(L, Sigma,Mu, m) ;