function [Lupdate]= AMCMC_MH_prec_init(L, sigma_MH, MALA, version, estL)
%%
% iniziation of Adaptive MCMC for cholesky of precision matrix
%	
%   L       - cholesky factor (lower triangular) (if options 1,2)
%             if option = 3
%             L{1} the likelihood
%             L{2} starting value
%
%
%   output:
%    Lupdate{1} - loglikelihood function (somethimes gradient out also)
%    Lupdate{2} - struct for updating cholesky factor
%    Lupdate{3} - cholesky factor
%    Lupdate{4} -  reodering for X
%    Lupdate{5} - strcut
%   .useMALA    - using MALA
%   .sigma_MH   - sigma_MH multiplicative factor
%   .lik_old    - likelihood for X
%   .X          - current "parameters"
%   .burnin     - self expl
%   .count      - number of smapels
%   .batch      - how often to update
%   Lupdate{6} - struct used for adapation of sigma_MH
%   Lupdate{7} - which version used
%
%   .accepantce_rate - sought accpetence rate
%   .batch      see AMCMC_MH_RR
%   .delta_min  see AMCMC_MH_RR
%   .delta_rate see AMCMC_MH_RR
%   .acc_vec    see AMCMC_MH_RR
%   .count      see AMCMC_MH_RR
%
%   sparse part (optional)
%	version - = 
%             = 2 - mex version of AMCMC (deafult)
%			  = 1 - regular AMCMC estimation
%
%   estL    - = 1 - estimation of cholesky factor
%               0 - estimation of Q (precision)
%
if nargin < 4
    version  = 2;
end
if nargin < 5
    estL = 1;
end

if nargin <3 
    MALA = 0;
end
Lupdate = cell(9,1);
Lupdate{7} = version;
Lupdate{1} = L{1};
    X = L{2};

if version == 1
    Lupdate{8} =  eye(length(X));
	Lupdate{3} =  eye(length(X));
    Lupdate{2} = cell(10,1);
    Lupdate{2}{10} = 1; %deafult rate
    Lupdate{2}{11} = zeros(length(X),1); %storing the mean
elseif version == 2 
    
        if MALA == 0
            Q = ordering_Q(L{2}, L{1});
        else
            Q = ordering_Q_grad(L{2}, L{1}); 
        end
        reo = amd(Q);
        if estL
            L = chol(Q(reo,reo))';
        else
            L = Q(reo,reo); 
        end

        Lupdate{2} =  Chol_init(L);
        Lupdate{3} =  speye(size(L));
        Lupdate{4} =  reo;
        Lupdate{8} =  speye(length(L));
        Lupdate{9} = estL;
    
end
    Lupdate{5} = struct;
    Lupdate{5}.sigma_MH = sigma_MH;
    Lupdate{5}.X        = X;
    Lupdate{5}.burnin   = 10^4;
    Lupdate{5}.batch    = 10;
    Lupdate{5}.count    = 0;
    Lupdate{5}.count_2  = 0;
    
    
    %% sigma infront
    Lupdate{6}          = struct;
    Lupdate{6}.batch    = 10;
    Lupdate{6}.delta_min = 0.1;
    Lupdate{6}.delta_rate = 1/2;
    Lupdate{6}.acc_vec    = 0;
    Lupdate{6}.count      = 0;
    if MALA == 0
        Lupdate{5}.lik_old = Lupdate{1}(X);
        Lupdate{5}.useMALA = 0;
        Lupdate{6}.accepantce_rate = 0.234;
    else
    [lik_old, dX] = Lupdate{1}(X); 
        Lupdate{5}.lik_old = lik_old;
        Lupdate{5}.useMALA = 1;
        Lupdate{5}.dX_old = dX; 
        Lupdate{6}.accepantce_rate = 0.55;
    end