function Lupdate =  Chol_init(L) 
%%
%   setups the objects needed for the cholesky updating
%   L  - (n x n) cholesky factor of the covariance!
%
%   Lupdate{1}  - number of elements in each row (excluding the diagonal)
%   Lupdate{2}  - the row index
%   Lupdate{3}  - the estimated values of \Sigma_{A_i,A_i}^{-1}
%   Lupdate{4}  - the estimated values of \Sigma_{A_i,i}
%   Lupdate{5}  - counts
%   Lupdate{6}  - the estimated values of \Sigma_{i,i} or residuals
%   Lupdate{7}  - the values of the rows of constructing L
%   Lupdate{8}  - for bulding L
%   Lupdate{9}  - the values of the D
%   Lupdate{10} - the rate
%
%%
n = length(L);

    Lupdate = cell(11,1);
    for i = 1:n
       row_index = setdiff( find(abs(L(:,i))>0),i);
       n_index   = length(row_index);
       A0 =1*eye(n_index,n_index);
       count = 4;


       Lupdate{1} = [Lupdate{1};length(row_index)];
       Lupdate{2} = [Lupdate{2};row_index - 1]; % -1 for C indexing
       Lupdate{3} = [Lupdate{3};A0(find(tril(ones(size(A0)))>0))];
       Lupdate{4} = [Lupdate{4};zeros(n_index, 1)];
       Lupdate{5} = [Lupdate{5};count];
       Lupdate{6} = [Lupdate{6}; count];  
       Lupdate{7} = [Lupdate{7};rand(n_index,1)];
       Lupdate{8} = [Lupdate{8}; i * ones(n_index,1)];  
    end
    Lupdate{8} = [Lupdate{8}; (1:n)']; 
    Lupdate{2} = [Lupdate{2}; (1:n)' - 1];  
    Lupdate{7} = [Lupdate{7}; -ones(n,1)];
    Lupdate{9} = zeros(n,1); 
    Lupdate{10} = 1; 
    Lupdate{11} = zeros(n,1); %storing the mean