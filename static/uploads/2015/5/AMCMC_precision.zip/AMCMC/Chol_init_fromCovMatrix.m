function Lupdate =  Chol_init_fromCovMatrix(L, Sigma, Mu, m) 
%%
%   setups the objects needed for the cholesky updating
%   L  - (n x n) cholesky factor of the covariance!
%
%   Sigma  (nxn)     - covariance matrix
%   m                - number of samples the covariance represents
%
%   Output:
%   Lupdate{1}  - number of elements in each row (excluding the diagonal)
%   Lupdate{2}  - the row index
%   Lupdate{3}  - the estimated values of \Sigma_{A_i,A_i}^{-1}
%   Lupdate{4}  - the estimated values of \Sigma_{A_i,i}
%   Lupdate{5}  - counts
%   Lupdate{6}  - the estimated values of \Sigma_{i,i} or residuals
%   Lupdate{7}  - the values of the rows of constructing L
%   Lupdate{8}  - for bulding L
%   Lupdate{9}  - the values of the D
%   Lupdate{10} - the rate
%
%%
n = length(Sigma);

Lupdate = cell(11,1);
for i = 1:n
   row_index = setdiff( find(abs(L(:,i))>0),i);
   n_index   = length(row_index);

    
   Lupdate{1} = [Lupdate{1};length(row_index)];
   Lupdate{2} = [Lupdate{2};row_index - 1]; % -1 for C indexing
   
   A_ii = Sigma(row_index, row_index);
   iA_ii = inv(A_ii);
   % Sigma_{A_i,A_i}^{-1} low triangular
   Lupdate{3} = [Lupdate{3};iA_ii(find(tril(ones(size(A_ii)))>0))];
   % Sigma_{A_i,i}
   Lupdate{4} = [Lupdate{4};Sigma(row_index, i)];
   Lupdate{5} = [Lupdate{5}; ceil(m)];
   Lupdate{6} = [Lupdate{6}; Sigma(i,i)];  
   Lv =  iA_ii * Sigma(row_index, i);
   Lupdate{7} = [Lupdate{7}; Lv ];
   Lupdate{8} = [Lupdate{8}; i * ones(n_index,1)];  
   Lupdate{9} = [Lupdate{9}; sqrt(Sigma(i,i) - Sigma(row_index, i)' * Lv)]; 
end
Lupdate{8} = [Lupdate{8}; (1:n)']; 
Lupdate{2} = [Lupdate{2}; (1:n)' - 1];  
Lupdate{7} = [Lupdate{7}; -ones(n,1)];
Lupdate{10} = 1; 
Lupdate{11} = Mu; 