function Q = ordering_Q(X, lik , index)
%%
% function for creating an approximate precision matrix
%
%   X     - (mx1) inital value of the log likelihood
%   lik   - function evalutes the likelihood
%   index - (kx1) the index of X that should be tested for sparsity
%%

if nargin < 3
    index = 1:length(X);
end

Q = zeros(length(index),length(index));
lx = lik(X);
step  = 3;
step2 = 5;
for i_=1:length(index)
    i = index(i_);
    Xeps = X;
    lx_1 = -inf;
    
    alpha = 1;
    while abs(lx_1) == inf
       Xeps(i) = X(i) + sign(rand-0.5)* alpha*step;
       lx_1 = lik(Xeps);
       alpha = alpha/2;
    end
    
    for j_ = (i_+1):length(index)
        j = index(j_);
        lx_2 = -inf;
        Xeps2 = X;
        alpha = 1;
        while lx_2 == -inf
            Xeps2(j) = X(j) + sign(rand-0.5)* alpha*step2;
            lx_2 = lik(Xeps2);
            alpha = alpha/2;
        end
        Xeps3 = Xeps2;
        Xeps3(i) = Xeps(i);
        lx_3 = lik(Xeps3);
        Q(i_,j_) = (lx_2 -lx) - (lx_3 - lx_1);
    end
    
end

Q = abs(Q) + abs(Q)';
Q(abs(Q)<10^-8) = 0;
Q(abs(Q)>0)=0.01 + rand(full(sum(sum(abs(Q)>0))),1);
Q = (Q + Q')/2;
Q = sparse(Q + 2*diag(sum(Q>0)));
