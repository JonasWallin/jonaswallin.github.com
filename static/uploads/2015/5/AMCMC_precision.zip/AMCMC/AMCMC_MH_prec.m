function [Lobj,L]=AMCMC_MH_prec(Lobj)
%%
%	AMCMC updating precision matrix or covariance
%	
%   Qb - cell(n,5) - Qb{1} - precision matrix
%                    Qb{2} - Q^-1 \mu
%                    Qb{3} - alpha
%                    Qb{4} - beta
%                    Qb{5} - index nonzero pattern
%%

X = Lobj{5}.X;
if Lobj{7}  == 1
    
    Lobj{5}.count = Lobj{5}.count  +1;
    Lupdate = Lobj{2};
    weight = 1/Lobj{5}.count ;
    if Lobj{5}.count == Lobj{5}.burnin
        Lobj{5}.sigma_MH =0.2* Lobj{5}.sigma_MH/sqrt(mean(diag(Lobj{8}*Lobj{8}')));
    end
    X_m = Lupdate{11}; 
    X_m = (1-weight)*X_m + weight*X;
    X = X - X_m;
    Lupdate{11} = X_m;
    
    
    if mod(Lobj{5}.count , Lobj{5}.batch) == 0  && Lobj{5}.count > Lobj{5}.burnin/2 
        
        Lobj{5}.count_2 = Lobj{5}.count_2  +1;
        weight = 1/Lobj{5}.count_2;
        Lobj{8} = cholupdate(sqrt(1-weight)* Lobj{8}', sqrt(weight)*X,'+')';
    end
    
    if Lobj{5}.count > Lobj{5}.burnin
        Lobj{3} = Lobj{8};
    else
        Lobj{3} = eye(size(Lobj{8}));
    end
    
elseif Lobj{7} == 2
    X =X(Lobj{4}); %reodering
    n = length(X);
    Lobj{5}.count = Lobj{5}.count  +1;
    Lupdate = Lobj{2};

    if Lobj{5}.count == Lobj{5}.burnin
        Lobj{5}.sigma_MH = 4*Lobj{5}.sigma_MH/sqrt(mean(diag(inv(Lobj{8}*Lobj{8}'))));
    end
    
    %if Lobj{5}.count > Lobj{5}.burnin
        
        weight = (1/Lobj{5}.count )^Lupdate{10};
        
        
    %elseif Lobj{5}.count < Lobj{5}.burnin
        
    %    weight = 0.01;
        %%
        % chaning count so it equals weight!
        %%
    %    rate = Lobj{2}{10};
    %    Lupdate{5} =(1/weight^(1/rate) )* ones(length( Lupdate{5}),1);
    %else
    %    weight = (1/Lobj{5}.count )^Lupdate{10};
    %    Lupdate{5} = min(Lupdate{5}, ceil(Lobj{5}.burnin/ Lobj{5}.batch));
    %end
    
    
    %weight = 1/Lobj{5}.count ;
    X_m = Lupdate{11}(Lobj{4}); %reodering
    X_m = (1-weight)*X_m + weight*X;
    X = X - X_m;
    Lupdate{11}(Lobj{4}) = X_m;
    
    if mod(Lobj{5}.count , Lobj{5}.batch) == 0 && Lobj{5}.count > Lobj{5}.burnin/2 
        Lobj{5}.count_2 = Lobj{5}.count_2  +1;
        Lupdate_mex(int32(n), X, int32(Lupdate{1}), int32(Lupdate{2}),Lupdate{3}, Lupdate{4},...
                    Lupdate{5}, Lupdate{6},Lupdate{7},Lupdate{9},Lupdate{10});
        if Lobj{9} == 1
            A = sparse(Lupdate{2} + 1, Lupdate{8} , -Lupdate{7},n,n);
            D = sparse(1:n,1:n,Lupdate{9});
            Lobj{8} = A*D ;
        else
            A = sparse(Lupdate{2} + 1, Lupdate{8} , -Lupdate{7},n,n);
            D = sparse(1:n,1:n,Lupdate{9}.^2 - 2);
            if Lobj{5}.count > Lobj{5}.burnin
                Lobj{8} = chol(A + D + A')';
            end
        end
    end
    if Lobj{5}.count >= Lobj{5}.burnin
        Lobj{3} = Lobj{8};
    else
        Lobj{3} = speye(size(Lobj{8}));
    end
end

Lobj{2} = Lupdate;
L = [];