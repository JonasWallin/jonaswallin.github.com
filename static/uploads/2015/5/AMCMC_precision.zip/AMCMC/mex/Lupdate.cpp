#include "Lupdate.h"

#define Calloc(n,type) (type *)calloc((size_t)(n),sizeof(type))


void rowLupdate(const int i, const double *X, const int n_element,
				const int* index, double* Ainv, double* b, 
				double * count, double * res, 
				 double *Lv, double *D)
{
				 
	count[0] += 0.5; // add constant here	
	//only diagonal element in the row
	if(n_element == 0)
	{
		res[0] += pow(X[i ] ,2)/2.;
		D[0] = 1./(pow( res[0] /( count[0] - 1.),0.5)); 
		return;
	}
	double *Z =  Calloc(n_element, double);
	for(int j =0; j < n_element ; j++){
		Z[j] = X[index[j] ];
		b[j] += Z[j] * X[i ]; // mult constant add here b?
	}
 	SH_sym(n_element, Ainv, Z);  // mult constant add here Ainv?
  low_triang_mult(n_element, Ainv, b, Lv);
	double Za = 0;
	for(int j =0; j < n_element ; j++)
		Za += Lv[j] * Z[j];
	res[0] += pow(X[i ] - Za,2)/2.; // add constant here
	D[0] = 1./(pow( res[0] /( count[0] - 1.),0.5)); 
	free(Z);			 	 
}
void rowLupdate_v2(const int i, const double *X, const int n_element,
				const int* index, double* Ainv, double* b, 
				double * count, double * res, 
				 double *Lv, double *D, const double rate)
{
				 
	count[0] += 1; // add constant here	
	double weight = 1/pow(count[0],rate); 
	double one_min_weight = 1 -weight;
	/*
		For instance: weight 
		set n = count
		weight = 1/n
		then
		1- 1/n = (n-1)/n
	
	*/
	//only diagonal element in the row
	if(n_element == 0)
	{
		res[0] *= one_min_weight;
		res[0] += weight * pow(X[i ] ,2);
		D[0] = 1./(pow( res[0],0.5)); 
		return;
	}
	double *Z  =  Calloc(n_element, double);
	double *wZ =  Calloc(n_element, double);
	for(int j =0; j < n_element ; j++){
		Z[j] = X[index[j] ];
		wZ[j] = weight * Z[j];
		b[j] *= one_min_weight;
		b[j] += wZ[j] * X[i ]; // mult constant add here b?
    wZ[j] =  wZ[j] / pow(weight, 0.5) ; // this needs to be added since we SH_sym uses wZ^T wZ
	}
	for(int j = 0; j < (n_element+1)*n_element/2; j++)
		Ainv[j] /= one_min_weight;
	
  // this incorrect? should use sqrt(w)?
  SH_sym(n_element, Ainv, wZ);  // mult constant add here Ainv?
	free(wZ);
	low_triang_mult(n_element, Ainv, b, Lv);
	double Za = 0;
	for(int j =0; j < n_element ; j++)
		Za += Lv[j] * Z[j];
	res[0] *= one_min_weight;
	res[0] += weight *pow(X[i ] - Za,2); // add constant here
	D[0] = 1./(pow( res[0] ,0.5)); 
	free(Z);			 	 
}

void rowLupdate_v3(const int i, const double *X, const int n_element,
  			const int* index, double* Ainv, double* b, 
				double * count, double * res, 
				 double *Lv, double *D, const double rate)
{
				 
	count[0] += 1; // add constant here	
	double weight = 1/pow(count[0],rate); 
	double one_min_weight = 1 -weight;
	/*
		For instance: weight 
		set n = count
		weight = 1/n
		then
		1- 1/n = (n-1)/n
	
	*/
	//only diagonal element in the row
	if(n_element == 0)
	{
		res[0] *= one_min_weight;
		res[0] += weight * pow(X[i ] ,2);
		D[0] = 1./(pow( res[0],0.5)); 
		return;
	}
	double *Z  =  Calloc(n_element, double);
	double *wZ =  Calloc(n_element, double);
	for(int j =0; j < n_element ; j++){
		Z[j] = X[index[j] ];
		wZ[j] = weight * Z[j];
		b[j] *= one_min_weight;
		b[j] += wZ[j] * X[i ]; // mult constant add here b?
    wZ[j] =  wZ[j] / pow(weight, 0.5) ; // this needs to be added since we SH_sym uses wZ^T wZ
	}
	for(int j = 0; j < (n_element+1)*n_element/2; j++)
		Ainv[j] /= one_min_weight;
	
  // this incorrect? should use sqrt(w)?
  SH_sym(n_element, Ainv, wZ);  // mult constant add here Ainv?
	free(wZ);
	low_triang_mult(n_element, Ainv, b, Lv);
	double Za = 0;
	for(int j =0; j < n_element ; j++)
		Za += Lv[j] * b[j];
	res[0] *= one_min_weight;
	res[0] += weight *pow(X[i ],2); // add constant here
	D[0] = 1./(pow( res[0] - Za ,0.5)); 
	free(Z);			 	 
}


void Lupdate(const int n, const double *X, const int* n_elements,
			  const int* indexs,
			 double* Ainvs, double* bs, double* counts, double* res,
			 double* Lv, double *D, const double rate)
			 
{



	int i;
	//int count_index = 0, count_Ainv = 0;
	/*
		UGLY UGLY HACK
	*/
	int *count_indexes =  Calloc(n, int);
	int *count_Ainv    =  Calloc(n, int);
	
	count_indexes[0]  = 0;//n_elements[0]; 
	count_Ainv[0]  = 0;//(n_elements[0] +1)*(n_elements[0])/2;
	for( i = 1; i < n; i++)
	{
		int n_element = n_elements[i-1];
		count_indexes[i] = n_element + count_indexes[i-1];
		count_Ainv[i]   = (n_element +1)*(n_element)/2 + count_Ainv[i-1];
	}
	
	#ifdef _OPENMP
		int nP = omp_get_num_procs();
	#else
		int nP = 1;
	#endif	
	#ifdef _OPENMP
		omp_set_num_threads(nP);
	#endif
	#pragma omp parallel 
	{
	#pragma omp for schedule(dynamic,1)
	for( i = 0; i < n; i++)
	{
		int n_element = n_elements[i];
		rowLupdate_v3(i, X, n_element,
				&(indexs[count_indexes[i]]), 
				&(Ainvs[count_Ainv[i]]),
				 &(bs[count_indexes[i]]), 
				&(counts[i]), &(res[i]), &(Lv[count_indexes[i]]),&(D[i]),
				rate);
        
        /*
    rowLupdate(i, X, n_elements[i],
  			&(indexs[count_index]), 
				&(Ainvs[count_Ainv]),
				 &(bs[count_index]), 
				&(counts[i]), &(res[i]), &(Lv[count_index]),&(D[i]));
        */
		//count_index += n_element;
		//count_Ainv  += (n_element +1)*(n_element)/2;
		
		
		
	}	
	}		 
	free( count_indexes);
	free( count_Ainv);
}