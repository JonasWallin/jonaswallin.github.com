#ifndef SHERMANMORR_H
#define SHERMANMORR_H

#include <math.h>
#include <stdlib.h>
#include <iostream>

//
/*
	Sherman Morrison formula for symmetry matrix A
	rank one update of the inverse:
	(A + uu')^-1
	
	overwrittes the second argument 

	@arg n dim of u
	@arg Ainv  lower triangular part of the matrix!
	@arg u vector
*/
void SH_sym(const int, double* , const double*);

void low_triang_mult(const int , const double* , const double* , double* );

#endif

