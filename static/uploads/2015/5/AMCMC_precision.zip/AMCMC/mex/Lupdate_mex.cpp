#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <stdlib.h>
#include <iostream>
#include "Lupdate.h"
void get_integer_scalar(int &scalar,const mxArray *mat_buf) {
    // Check input

    if (mxGetNumberOfElements(mat_buf) == 1) {
        scalar = mxGetScalar(mat_buf);
    } else {
    	int M= mxGetM(mat_buf);
        mexPrintf("M = %d\n", M);
        mexErrMsgTxt("Integer scalar is not of size == [1 1].\n");
        
    }
}



void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	#define n_in        prhs[0] // row of L
	#define X_in        prhs[1] // X
	#define ne_in       prhs[2] // number of elements of the row (non diagonal)
	#define indexs_in   prhs[3] // position of the elements (non diagonal)
	#define Ainv_in     prhs[4] // lower triangular part of the triangle
	#define bs_in       prhs[5] // right hand side
	#define count_in    prhs[6] // used to update variance (D)
	#define res2_in     prhs[7] // residuals used to update(D)
	#define Lv_in       prhs[8] // used to update variance (D)
	#define D_in        prhs[9] // residuals used to update(D)
	#define rate_in     prhs[10] // residuals used to update(D)
	if(nrhs != 11)
		mexErrMsgTxt("wrong number of input argumets.");
	if(nlhs != 0)
		mexErrMsgTxt("wrong number of output argumets.");

	int   n;
	get_integer_scalar(n, n_in);
	
	// input arguments:
	int    *n_elements;
	n_elements =  (int *) mxGetData(ne_in);
	double *X      = mxGetPr(X_in);
	double *Ainvs  = mxGetPr(Ainv_in);
	int    *indexs =  (int *) mxGetData(indexs_in);
	double *bs     = mxGetPr(bs_in);
	double *count  = mxGetPr(count_in);
	double *res2   = mxGetPr(res2_in);
	double *Lv     = mxGetPr(Lv_in);
	double *D      = mxGetPr(D_in);
	double *rate   = mxGetPr(rate_in);
	
	Lupdate(n, X, n_elements, indexs,
			  Ainvs, bs, count, res2, Lv, D, rate[0]);
	return;
}
