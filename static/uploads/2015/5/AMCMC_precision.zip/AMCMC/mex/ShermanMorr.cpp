
#include "ShermanMorr.h"

#define Calloc(n,type) (type *)calloc((size_t)(n),sizeof(type))

void low_triang_mult(const int n, const double* A, const double* x, double* b)
{
	int i,j;
	int count =0;
	double x_i, A_ij;
	for( i = 0; i < n; i++)
		b[i] = 0;
	for( i = 0; i < n; i++)
	{	
	    x_i = x[i];
		b[i] += A[count++]*x_i;
		for( j = i+1; j < n; j++){
			A_ij = A[count++];
			b[j] += A_ij * x_i;
			b[i] += A_ij* x[j];
		}
	}
}

void SH_sym(const int n, double*  Ainv, const double* u)
{

    double * Ainv_u =  Calloc(n, double);
	
	//creating
	// vector A^-1u 
	// and constant 1+u'A^-1u 
	double A_ij, u_i;
	int count =0;
	int i,j; 
	double uAinvu =1.;
	for( i = 0; i < n; i++)
	{	
	    u_i = u[i];
		Ainv_u[i] += Ainv[count++]*u_i;
		for( j = i+1; j < n; j++){
			A_ij = Ainv[count++];
			Ainv_u[j] += A_ij * u_i;
			Ainv_u[i] += A_ij * u[j];
		}
		uAinvu += Ainv_u[i]*u_i;
	}
	
	//outer product 
	// storying (Au)(Au)'/(1+ u'Au) in the lower triangular array
	// (A + uu')^-1 = A^-1 -  (Au)(Au)'/(1+ u'Au)
	count =0;
	double Ainv_u_div_cont;
	for( i = 0; i < n; i++)
	{	
		Ainv_u_div_cont = Ainv_u[i] / uAinvu;
		Ainv[count++] -= Ainv_u[i] * Ainv_u_div_cont;
		for( j = i+1; j < n; j++){
			Ainv[count++] -= Ainv_u[j] * Ainv_u_div_cont;
		}
		
	}
	free(Ainv_u);
}
