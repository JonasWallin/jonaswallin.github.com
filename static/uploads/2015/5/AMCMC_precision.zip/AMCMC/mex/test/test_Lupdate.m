%%
%   some simple test verfiying that things work correctly!
%
%%

close all
clear all
addpath ../../
addpath ../
Sigma = [4 1 ; 1 2];
Q = inv(Sigma);
n = 2;
X = [2,1]';
X2 = [2,0.1]';


L =  chol(Q)'; 
Lupdate = cell(11,1);
L_check =  cell(3,1); 
L_check{1} = cell(2,1);
for i = 1:2
   row_index = setdiff( find(abs(L(:,i))>0),i);
   n_index   = length(row_index);
   A0 =1*eye(n_index,n_index);
   count = 4;


   Lupdate{1} = [Lupdate{1};length(row_index)];
   Lupdate{2} = [Lupdate{2};row_index - 1]; % -1 for C indexing
   Lupdate{3} = [Lupdate{3};A0(find(tril(ones(size(A0)))>0))];
   Lupdate{4} = [Lupdate{4};zeros(n_index, 1)];
   Lupdate{5} = [Lupdate{5};count];
   Lupdate{6} = [Lupdate{6}; count];  
   Lupdate{7} = [Lupdate{7};rand(n_index,1)];
   Lupdate{8} = [Lupdate{8}; i * ones(n_index,1)]; 
   
   
end
    Lupdate{8} = [Lupdate{8}; (1:n)']; 
    Lupdate{2} = [Lupdate{2}; (1:n)' - 1];  
    Lupdate{7} = [Lupdate{7}; -ones(n,1)];
    Lupdate{9} = zeros(n,1); 
    Lupdate{10} = 1; 
    Lupdate{11} = zeros(n,1); %storing the mean
S1 = (count)/(count+1) + X(2)^2/((count+1) );
 L_check{1}{1} = 1/S1;
 S2 = S1*(count+1)/(count+2) + X2(2)^2/(count+2);
 L_check{1}{2} = 1/S2;  

Lupdate_mex(int32(n), X, int32(Lupdate{1}), int32(Lupdate{2}),Lupdate{3}, Lupdate{4},...
                    Lupdate{5}, Lupdate{6},Lupdate{7},Lupdate{9},Lupdate{10});
 if abs(Lupdate{3}    -  L_check{1}{1})     > 10^-6
     disp('Ainv failed first update')
 else
     disp('.')
 end
 Lupdate_mex(int32(n), X2, int32(Lupdate{1}), int32(Lupdate{2}),Lupdate{3}, Lupdate{4},...
                     Lupdate{5}, Lupdate{6},Lupdate{7},Lupdate{9},Lupdate{10});
 if abs(Lupdate{3}    -  L_check{1}{2})     > 10^-6
     disp('Ainv failed second update')
 else
     disp('.')
 end

A = sparse(Lupdate{2} + 1, Lupdate{8} , -Lupdate{7},n,n);
D = sparse(1:n,1:n,Lupdate{9});