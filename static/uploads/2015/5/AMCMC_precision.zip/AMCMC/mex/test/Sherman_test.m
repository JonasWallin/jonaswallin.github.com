%%
%%
%% Function for testing SH-formula
%% the function assumes the triangular output is lower triangular!
%%
%%
clear all
close all
n  =5;
A = rand(n,n);
A = A+A';
Ainv = inv(A);
u =  rand(n,1); 
addpath ../

A_in =  A(find(tril(ones(size(A)))>0));
test_SM(A_in,u);

A_res = inv(Ainv+u*u');
if( max(abs(A_res(find(tril(ones(size(A)))>0)) - A_in)) > 10^-10)
   disp(' SH formula for symmetric failed') 
else
    disp('.') 
end
