%%
%%
%% main for testing Cholesky lower update 
%%
%%
close all
clear all
X = [  0.9879    0.3751    1.4845   -1.1287 ...
    0.3111   -0.7486   -0.8962    1.5966   -0.6611    0.0211]';
i = 1;
Ai =[];
Aj = [];
Az = [];
Qb= cell(1,10);
   Qb{i,5} = [2,3]';
   n_index = length(Qb{i,5});
   Qb{i,1} = [    0.20    0.1; ...
                  0.1    0.23];
   Qb{i,2} = [ -206.5323
                179.6133];
   Qb{i,3} = 502;%alpha
   Qb{i,4} = 301.1695;   
   
   Z = X(Qb{i, 5});
    n_i = length(Z);
    Q_i = Qb{i, 1};
    ZtQ_i = Z'*Q_i;
    c   = 1 + ZtQ_i*Z;
    Q_i = Q_i - (ZtQ_i'*ZtQ_i)/c;
    Qb_ = Qb{i, 2} + Z*X(i);
    a = Q_i*Qb_;
    Ai  = [Ai ;Qb{i, 5}];
    Aj  = [Aj ; i * ones(n_i,1)];
    Az  = [Az ; -a];
    Ainv_ = Qb{i,1}(find(tril(ones(size(Qb{i,1})))>0));
    
     Qb_3 = Qb{i, 3} + 1/2;
    if isempty(a) == 0
        Qb_4 = Qb{i, 4} + (X(i) - Z'*a)^2/2;
    else
        Qb_4 = Qb{i, 4} + X(i)^2/2;
    end
    D(i,i) = 1/sqrt( Qb_4/(Qb_3 - 1));
    
    
[ Lz, Dz] = test_Lrow_update(int32(i-1), X, int32(length(Qb{i,5})),...
                    int32(Qb{i,5}-1), Ainv_, ...
                    Qb{i, 2}, Qb{i,3}, Qb{i,4});
                
if( max(abs(Q_i(find(tril(ones(size(Qb{i,1})))>0)) - Ainv_)) > 10^-10)
   disp(' SH formula for symmetric failed in Lupdate') 
else
    disp('.') 
end        
if( abs(D-Dz) > 10^-10)
   disp(' Diagonal elment in Lupdate failed') 
else
    disp('.') 
end  
if( max(abs(a-Lz)) > 10^-10)
   disp(' updated elment for L in Lupdate failed') 
else
    disp('.') 
end 