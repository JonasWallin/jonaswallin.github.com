#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <stdlib.h>
#include <iostream>
#include "ShermanMorr.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	//#define Ainv_u_OUT     plhs[0]
	//#define n_in         prhs[0]
	#define Ainv_in        prhs[0]
	#define u_in           prhs[1]
	if(nrhs<2)
		mexErrMsgTxt("wrong number of input argumets.");
	if(nlhs != 0)
		mexErrMsgTxt("wrong number of output argumets.");



	double *Ainv, *u;
	int n;
	Ainv    = mxGetPr(Ainv_in);
	u       = mxGetPr(u_in);
	n       = mxGetM(u_in);
	
	SH_sym(n, Ainv , u);
	return;
}
