#include <math.h>
#include <matrix.h>
#include <mex.h>
#include <stdlib.h>
#include <iostream>
#include "Lupdate.h"
void get_integer_scalar(int &scalar,const mxArray *mat_buf) {
    // Check input

    if (mxGetNumberOfElements(mat_buf) == 1) {
        scalar = mxGetScalar(mat_buf);
    } else {
    	int M= mxGetM(mat_buf);
        mexPrintf("M = %d\n", M);
        mexErrMsgTxt("Integer scalar is not of size == [1 1].\n");
        
    }
}



void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
	#define Lv_OUT      plhs[0] // values
	#define D_OUT       plhs[1] // Diagonal value of D
	#define iL_in       prhs[0] // row of L
	#define X_in        prhs[1] // X
	#define n_in        prhs[2] // number of elements of the row (non diagonal)
	#define index_in    prhs[3] // position of the elements (non diagonal)
	#define Ainv_in     prhs[4] // lower triangular part of the triangle
	#define b_in        prhs[5] // right hand sied
	#define count_in    prhs[6] // used to update variance (D)
	#define res2_in     prhs[7] // residuals used to update(D)
	if(nrhs != 8)
		mexErrMsgTxt("wrong number of input argumets.");
	if(nlhs != 2)
		mexErrMsgTxt("wrong number of output argumets.");

	int n_elements, i_L;
	get_integer_scalar(n_elements, n_in); 
	
	// input arguments:
	double *count_res     = mxGetPr(count_in);
	double *X     = mxGetPr(X_in);
	double *res2 = mxGetPr(res2_in);
	double *Ainv  = mxGetPr(Ainv_in);
	double *b     = mxGetPr(b_in);
	int    *index =  (int *) mxGetData(index_in);
	
	
	// output arguments:
	Lv_OUT = mxCreateDoubleMatrix(n_elements, 1, mxREAL);
	double *Lv =  mxGetPr(Lv_OUT);	
	D_OUT  = mxCreateDoubleMatrix(1, 1, mxREAL);
	double *D_point = mxGetPr(D_OUT);
	
	rowLupdate(i_L, X, n_elements,
			   index, Ainv, b, 
			 count_res, res2, 
			Lv, D_point);
	return;
}
