#ifndef LUPDATE_H
#define LUPDATE_H
#include "ShermanMorr.h"

#include <math.h>
#include <stdlib.h>
#ifdef _OPENMP
  #include <omp.h>
#endif

/*
Update a row in L (lower triangular matrix cholesky factor)
using regeression,
E[x_i| X_{(i+1):n}] = sum(L_{(i+1):n}*X)
V[x_i| X_{(i+1):n}] = 1/L_{i,i}^2
thus L can be estimated through regression!
A * L = b ( L = Ainv * b)

@arg i          - row index
@arg X          - values of the data that updates matrix
@arg n_element  - number of elements in the row under diagonal
@arg index      - the position of the elemnts in the row under diagonal
@arg Ainv       - inverse of updating matrix lower triangular
@arg b          - right hand side regression
@arg count      - element used for variance estimation
@arg res        - element used for variance estimation (residual squared)
@arg Lv         - arguments for the triangle
@arg D          - Diagnonal component in L
*/
void rowLupdate(const int i, const double *X, const int n_element,
				const int* index, double* Ainv, double* b, 
				double * count, double * res, 
				 double *Lv, double *D);
/*
Same as rowLupdate however slower updating rate then rowLupdate

@arg rate          - option to set rate of updating parameters
*/
void rowLupdate_v2(const int i, const double *X, const int n_element,
				const int* index, double* Ainv, double* b, 
				double * count, double * res, 
				 double *Lv, double *D, const double rate);

/*
Update a  L (lower triangular matrix cholesky factor)
using regeression,
E[x_i| X_{(i+1):n}] = sum(L_{(i+1):n}*X)
V[x_i| X_{(i+1):n}] = 1/L_{i,i}^2
thus L can be estimated through regression!
A * L = b ( L = Ainv * b)

@arg n          - number of rows
@arg X          - values of the data that updates matrix
@arg n_elements - [i]  number of elements in the row under diagonal of row i 
@arg indexs     - the position of the elemnts in the row under diagonal, for all 
				  rows	
@arg Ainvs      - inverse of updating matrix lower triangular, all matrices columnstacked
@arg bs         - right hand side regression, all vectors columnstacked
@arg count      - [i] element used for variance estimation for row i
@arg res        - [i] element used for variance estimation for row i (residual squared)
@arg Lv         - arguments for the triangle, all vectors columnstacked
@arg D          - [i] Diagnonal component in L
@arg rate          - option to set rate of updating parameters
*/
void Lupdate(const int n, const double *X, const int* n_elements,
			  const int* indexs,
			 double* Ainvs,double* bs, double* count, double* res , double *Lv, double *D,
			 const double rate);
#endif

