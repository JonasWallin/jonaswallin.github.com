function Q = ordering_Q_grad(X, lik , index)
%%
% function for creating an approximate precision matrix
%
%   X     - (mx1) inital value of the log likelihood
%   lik   - function evalutes the likelihood, can compute gradient
%   index - (kx1) the index of X that should be tested for sparsity
%%

if nargin < 3
    index = 1:length(X);
end

Q = zeros(length(index),length(index));
[lx , l_dx ]= lik(X);
if lx == -Inf
   disp('unbounded likelihood at inital guess');
   return
end
step  = 5;
for i_=1:length(index)
    i = index(i_);
    Xeps = X;
    lx_1 = -inf;
    
    alpha = 1;
    while abs(lx_1) == inf
       Xeps(i) = X(i) + sign(rand-0.5)* alpha*step;
       [lx_1, l_dx1] = lik(Xeps);
       alpha = alpha/2;
    end
    Q(:,i) = l_dx1-l_dx;
    
end

Q = abs(Q) + abs(Q)';
Q(abs(Q)<10^-14) = 0;
Q(abs(Q)>0)=0.01 + rand(full(sum(sum(abs(Q)>0))),1);
Q = (Q + Q')/2;
Q = sparse(Q + 2*diag(sum(Q>0)));
