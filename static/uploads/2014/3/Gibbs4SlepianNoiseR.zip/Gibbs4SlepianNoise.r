
library(rGIG)
source("rtiltrayleigh.r")


scalar_to_vec <- function(a,n)
{
  # Function for chaning scalar to vector of length n
  # if a is alredy a vector, then the function does nothing
  if(length(a) == 1)
  {
    a = rep(a,n)
  }
  return(a)
}

sampling_biased_K = function(L, p, a = 2, b = 0)
{
  # Sampling the underlying variance (K) component in:
  # MODEL:
  #   L(s) = B(K(s)) 
  #   where L is symmetric GAL noise with \lambda shape parameter
  #   thus uncondionaly K    ~ GIG( \lambda * dx, 2, 0)   
  #   and              K|L  ~ GIG( \lambda * dx, 2,  L^2)
  #
  # args:
  # L  - (nx1)   discretized version of dL(s)
  # p  - (nx1, double)   either a vector corresponding to \lambda * dx_i,
  #                       or scalar : \lambda * dx
  # a  - (nx1, double)   vector: a_i, scalar: a. deafult: a=2
  # b  - (nx1, double)   vector: b_i, scalar: b. deafult: b=0
  #
  # returns:
  # K -  (nx1)  simulation of the discretization vestion of K(s)
  n <- length(L)
  p <- scalar_to_vec(p,n)
  a <- scalar_to_vec(a,n)
  b <- scalar_to_vec(b,n)
  
  K <- rGIG(p,  a, b + L^2)
  
  return(K)
}


sampling_biased_L = function(K, X0, f, dX0 = NA, df = NA)
{
  #   Sampling underlying noise (L) from given X(0),X'(0), and K:
  #   MODEL:
  #   X(t) = \int f(t-s) dL(s)
  #   L(s) = B(K(s))
  #
  # args:
  # K   - (nx1)    vector of the discretization K(s)
  # X0  - (double) the value of X(0)
  # f   - (nx1)   the discretization of f(s)
  # dX0 - (double) the value of X'(0). 
  #                if = NA conditoning only on X(0)
  # df  - (nx1)   the discretization of f'(s)
  #
  # returns:
  #
  # dL  - (nx1)  simulation of the discretization vestion of L(s)
  #
  #
  # EXAMPLE: 
  # Simulating X(t) = \int f(t-s) dB(s) where f(t) = e^(-t^2)I_{t>=0}(t) 
  #
  # code:
  # T = 5 # Sample in [-T, T]
  # #discritization of intervall
  # dx = 2^(-6); x = c(seq(-T ,-dx ,dx),seq(dx, T ,dx)); n = length(x);
  # x_mid = (x[2:n] + x[1:(n-1)]) /2; n = n - 1;   # taking the mid point
  # f <- function(x) {exp(-x^2) * (x>=0)}
  # f_v  = f(x_mid)   # discretization of f on [-T,T]
  # df <- function(x) {-2*x*exp(-x^2) * (x>=0)}
  # df_v = df(x_mid)  # discretization of f' on [-T,T]
  # K = rep(dx,n)     # since Brownian moition use K is only
  #                   # the discritzation
  # # sampling the underlying browninan moiton (B) 
  # # given that X(0) = 6
  # B = sampling_biased_L(K, 6, f_v)
  # # given that X(0) = 6, X'(0) = 5
  # B_2 = sampling_biased_L(K, 6, f_v, 5, df_v)

  f2 =   f * f
  

  # conditoning only on X0
  if(is.na(dX0))
  {
    # V[X] = K^T * f.^2
    V_X =  sum(f2 * K)
    # C[X, L] = K .* f
    C_X_L = K * f
    
    # simulating the uncoditional distribution
    L_  = sqrt(K)*rnorm(n = length(K))
    # X0  = \int f  dL,
    X0_ = sum(f*L_)
    
    # simulating the conditional distribution
    # L | X0 
    L = L_ + (C_X_L / V_X) * (X0 - X0_ )
  }
  else
  {
    
    fdf =  f * df
    df2 = df * df
    # 
    # Covariance matrix of X and dX
    # [ K^T * f.^2    , K^T * (f.*df) ]
    # [ (f.*df) * K^T , K^T * df.^2   ]
    V_X_dX = matrix(nrow = 2, ncol = 2)
    V_X_dX[1, 1] = sum(f2 * K)
    V_X_dX[1, 2] = sum(fdf * K)
    V_X_dX[2, 1] = V_X_dX[1, 2]
    V_X_dX[2, 2] = sum(df2 * K)
    
    # C[X, L] = K .* f
    C_X_L = K * f
    # C[dX, L] = K .* df
    C_dX_L = K * df
    
    # simulating the uncoditional distribution
    # dL
    L_  = rnorm(n = length(K), sd = sqrt(K))
    # X0  = \int f  dL,
    # dX0 = \int f' dL
    X_ = c(sum(L_*f) , sum(L_ * df)) 

    # simulating the conditional distribution
    # dL | X0 dX0
    L = L_ + cbind(C_X_L, C_dX_L) %*% solve(V_X_dX, rbind(X0,dX0) -  X_)
  }
  
  return(L)
}

sampling_MGALup = function(X0, f, lambda_dx,  df , K = NA, sim  = 10)
{
  #   Sampling underlying noise and variance (L,K, dX0) from given a up crossing of X(0)  :
  #   MODEL:
  #   X(t) = \int f(t-s) dL(s)
  #   L(s) = B(K(s)),
  #   K(s) ~ \Gamma(\lambda,1) 
  #
  #   The simulation is preformed using a Gibbs sampler
  #
  # args:
  # X0        -  (double) the value of X(0)
  # f         -  (nx1)    the discretization of f(s)
  # lambda_dx -  (double) scalar dx*lambda, dx is the length of an interval
  #                      in the discretization
  # df        -  (nx1)   the discretization of the kernel of the derivative process (can be f'(s) or -f'(s) depending how the moving average process is defined)
  # K         -  (nx1)   Inital guess of K(s)
  # sim       -  (int)   number of simulation in the Gibbs sampler
  #
  # returns:
  #
  # KL  - (list)  
  #     $L   (nx1)   simulation of the discretization vestion of L(s)
  #     $K   (nx1)   simulation of the discretization vestion of K(s)
  #     $dX0 (1)     simulatio of the derivative at 0s
  #
  dX0  = 2 #start guess
  n = length(f)
  if(is.na(K)[1])
  {
    K_sample = rep(1, n)
  }
    for(i in 1:sim)
    {
      L_sample = sampling_biased_L(K_sample, X0, f, dX0, df) 
      K_sample = sampling_biased_K(L_sample, p = lambda_dx -  1/2)
      
      df2k = sum(df * df * K_sample)
      f2k  = sum( f *  f * K_sample) 
      r = sum( f * df * K_sample) / sqrt(df2k * f2k)
      a = X0 * r * sqrt(df2k/f2k)
      b = 2 * (1 - r^2) * df2k 
      dX0 = sqrt(b) * rtiltrayleigh(a/sqrt(b))
    }
  
  return(list(K=K_sample, L=L_sample, dX0 = dX0))
}

