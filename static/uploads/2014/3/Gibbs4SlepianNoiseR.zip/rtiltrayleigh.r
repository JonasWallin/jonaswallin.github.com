biasr1=function(a=0){    #rejection algorithm #1
if(a==0){  x-sqrt(-2*log( runif(1)))/sqrt(2)
}else{  
repeat{
  if(a < sqrt(pi)){
  x=a*sqrt(runif(1)); 
  if(runif(1)<=exp(-(x-a)^2)){break()}
  
  }
  else
  {
    x = a - sqrt(2)/2 * abs(rnorm(1))
    if(runif(1)<=x/a){break()}
  }

}



}
return(x)}                        

rtiltrayleigh=function(a=0)
{
 if(a>0){  
   x=a	
	 A=sqrt(pi)*a; B=exp(-a^2)+2*A*pnorm(sqrt(2)*a)
	 l1=1/B; l2=A*l1; l3=1-l1-l2
	 s=sample(c(1,2,3),1,prob=c(l1,l2,l3))
	
	 if(s==1){  x=x+sqrt(rexp(1))
	 }else{ if(s==2){
		              x=x+sqrt(2)/2*abs(rnorm(1))
		              }else{ x=biasr1(a) }
          }
 }else{
   a_neg = -a
   if(a_neg < 0.5)
   {
     repeat{
       R = sqrt(-2*log( runif(1)))/sqrt(2)
       if(runif(1) < exp(-2 * a_neg * R))
       {
         x = R
         break()
       }
     }
     
   }else{
     repeat{
       G = rgamma(1, shape = 2, rate = (2 * a_neg))  
       if(runif(1) < exp(-G^2))
       {
         x = G
         break()
       }
     }
   }
#      if(a>-1){                              #rejection algorithm #2
# 	          repeat{x=-(rexp(1)+rexp(1))/(2*a) 
# 	          if(runif(1,max=x*exp(2*a*x))<=(x*exp(-(x-a)^2))) break()}
# 	          }else{                        #numerical approximation
# 	                u=runif(1) 
# 	                C=1/(exp(-a^2)+2*sqrt(pi)*a*pnorm(sqrt(2)*a))             
# 	                f=function(x) (exp(-(x-a)^2)+2*sqrt(pi)*a*pnorm(sqrt(2)*(a-x)))/C-u
#                     xmin = uniroot(f, c(0,1000), tol = 0.0001)
#                     x=xmin$root}
 }
return(x)}
