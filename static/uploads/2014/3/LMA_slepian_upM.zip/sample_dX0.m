function dx0 = sample_dX0(x0, df2, f2, fdf, v)
%%
% Samples the derivative of the upcrossing of a Slepian Laplace moving average 
% the distribution is:
%       \pi(x) = x exp( - (x-a)^2/b), x>0 
%       where
%       a = E[X'(0)| X(0)=x0, V = v]
%       b = V[X'(0)| X(0)=x0, V = v]
%       From the model:
%       X(t) \int f(t-s) dL(s) ,
%       dL(s) = \sqrt(V) Z
%       V     ~ \Gamma(1/nu, nu) (shape, scale)
%       Z     ~ N(0,1)
%
%       input:
%       x0      - (double)     the value at the crossing (X(0))
%       f2       - (nx1)       the kernel squared (equidistance only)
%       df2      - (nx1)       the derivative of the kernel squared
%       fdf      - (nx1)       the derivative of the kernel hadmard product
%                              with the kernel (f.*df)
%       v       - (nx1 > 0)    the variance component of the GAL noise
%
%       output:
%       dx0     - (double > 0) the simulated derivative
%%

df2k = sum(df2 .*v);
f2k  = sum( f2  .*v);
r    = sum( fdf  .*v) / sqrt(df2k * f2k);
a    = x0 * r * sqrt(df2k/f2k);
b    = 2 * (1 - r^2) *df2k;
dx0 = sqrt(b) * rtiltrayleigh(a/sqrt(b));