function x = rtiltrayleigh(a)
%%
%
%   Function sampling biased rayleigh
%   f(x) = x exp(-(x-a)^2) I(x>0)
%
%
%%


if (a==0)
    x = sqrt(-log(rand));
elseif( a>0)
    

    A = sqrt(pi) * a;
    B = exp(-a^2) + 2*A * normcdf(sqrt(2) * a);
    l1 = 1 / B;
    l2 =  A  * l1;
    U = rand;
    if U < l1
        x = a + sqrt(exprnd(1));
    elseif U < l1 + l2
        x = a + (1 / sqrt(2) ) * abs(randn);
    else
        x = rejection1(a);
    end
else
    x = rejection_neg(-a);
end


end

function x = rejection_neg(a)

    
    if a < sqrt(0.5)
       x = sqrt(-2*log(rand))/sqrt(2);
       while rand > exp(-2 * a * x)
           x = sqrt(-2*log(rand))/sqrt(2);
       end
        
    else
       x = gamrnd(2, 2 * a);
       while rand > exp(-x^2)
           x = gamrnd(2, 1/(2 * a));
       end
    end
end


function x = rejection1(a)
if( a < sqrt(pi) )
    
    x = a * sqrt(rand);
    while rand > exp(-(x-a)^2)
        x = a * sqrt(rand);
    end
    
else
    x = a  - (1/sqrt(2))  * abs(randn);
    while rand > x/a
        x = a  - (1/sqrt(2))  * abs(randn);
    end
    
end


end