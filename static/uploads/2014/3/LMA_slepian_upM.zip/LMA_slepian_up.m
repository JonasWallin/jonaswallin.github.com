function [dl, v, dx0] = LMA_slepian_up(x0, f, df, nu, dx, sim, v0, gauss)
%%
%   samples noise at upcrossing for a Slepian distribution
%   for a moving average driven by generalised laplace noise
%   the model is
%       X_t = \int f(t-s) dLambda(s)
%
%       Lambda(1) ~ \sqrt(V) Z,
%       V         ~ \Gamma(1/nu, nu) (shape, scale)
%       Z         ~ N(0,1)
%
%
%       input:
%       x0      - (double)    the value at the crossing
%       f       - (nx1)       the kernel (equidistance only)
%       df      - (nx1)       the derivative of the kernel (equidistance only)
%       nu      - (double >0) the parameter of the noise
%       dx      - (double >0) discretization step size of f
%       sim     - (int)       number of simulation to run the Gibbs sampler
%       gauss   - (int)       1 indicates that we dont use Laplace but
%                             Gaussian noise
%
%
%       output:
%       dl       - (nx1)      the slepian noise
%       v        - (nx1)      the slepian Gamma
%       dx0      - (duble >0) the behaviour of the derivative at the
%                             upcrossing
%%




n = length(f);
p = ones(n, 1)*( dx /nu - 1/2);
a = (2 / nu) * ones(n, 1);

if nargin <7
    v0 = [];
end
if isempty(v0)
    v = dx * ones(n,1);
else
    v = v0;
end

if nargin < 8
   gauss = 0; 
end

f2  = f.*f;
df2 = df.*df;
fdf = df.*f;

if gauss == 1
    sim = 1;
    v = dx*ones(n,1);
end

for i = 1:sim
    dx0 = sample_dX0(x0, df2, f2, fdf, v);
    dl   = sample_dL(x0, v, f, f2, dx0, df, df2, fdf);
    if gauss == 0
        v = sample_V(p, a, dl);
    end
end

