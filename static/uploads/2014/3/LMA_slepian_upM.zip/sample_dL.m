function dl = sample_dL(x0, v, f, f2, dx0, df, df2, fdf)
%%
%       Generates a sample of dL(s) (discretization)
%       from the model
%       X(t) \int f(t-s) dL(s) ,
%       dL(s) = \sqrt(V) Z
%       V     ~ \Gamma(1/nu, nu) (shape, scale)
%       Z     ~ N(0,1)
%       and given X(0) = x0 , dX(0) = dx0 , V = v
%
%       input
%       x0       - (double)    the value of X(0)
%       f2       - (nx1)       the kernel (equidistance only)
%       v        - (nx1 > 0)   the variance component of the GAL noise
%       f2       - (nx1)       the kernel squared (equidistance only)
%       dx0      - (double)    the value of X'(0)  
%       df       - (nx1)       the derivative of the kernel 
%       df2      - (nx1)       the derivative of the kernel squared
%       fdf      - (nx1)       the derivative of the kernel hadmard product
%                              with the kernel (f.*df)
%
%       output:
%       dl      -  (nx1)        samples of the noise (dL(s) )
%
%%
if nargin< 5
    dx0 = [];
    
end
n = length(v);

if isempty(dx0) == 1
    vgg = (v'*f2);
    gv =  (f.* v);
    
    % using trick for fast simulation
    z = randn(n,1);
    % l uncondtional
    l_u = sqrt(v).*z;
    % uncodtinal X(0)
    x_u = f'*l_u;
    dl = l_u + (gv / vgg) * (x0 - x_u);
else
    V = zeros(2,2);
    V(1,1) = sum(f2.*v);
    V(2,1) = sum(fdf.*v);
    V(1,2) = V(2,1);
    V(2,2) = sum(df2.*v);
    
    C_X  =  f .* v;
    C_dX = df .* v;
    
    z = randn(n,1);
    % l uncondtional
    l = sqrt(v).*z;
    
    % uncodtinal X(0) X'(0)
    X_ = [f' * l; df' * l];
    dl = l + [C_X, C_dX] * (V\( [x0; dx0] - X_));
    
end