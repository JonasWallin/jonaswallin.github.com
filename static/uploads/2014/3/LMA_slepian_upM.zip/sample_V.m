function V = sample_V(p, a, l)
%%
% Samples V from
% L = \sqrt(V) Z
% V     ~ \Gamma(p + 1/2, a/2) (shape, scale)
% Z     ~ N(0,1)
% Given that L = l
%
%   input:
%   p   -   (nx1) shape parameter 
%   a   -   (nx1) scale parameter
%   l   -   (nx1) the noise
%   output:
%   v   -   (nx1) sample of V
%
%%


b = l.^2 ;
    
index =b> 0;
V = zeros(length(b), 1);
seed = ceil(rand(6,1)*10^6);
V(index)  = rgig_par(p(index), a(index), b(index), seed);
%V(index)  = gig_matlab(p(index), a(index), b(index));

log_b = 2 * log(abs(l(~index))) + eps ;
log_a = log(a(~index));
log_alpha = (log_a -  log_b)/2;
log_beta  = (log_a + log_b) /2;
log_x = zeros(sum(~index),1);
p_temp = -p(~index);
for j = 1:length(p_temp)
    temp = 1;
    while temp > 0
        log_x_s = log(gamrnd(p_temp(j), 2, 1,1))  - log_beta(j);
        U = rand;
        if log(U) < -exp(log_beta(j)-log_x_s)/2;
            temp = 0;
        end
    end
    log_x(j) =  - log_x_s - log_alpha(j);
end
V(~index) = exp(log_x);