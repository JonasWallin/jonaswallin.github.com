sim = 1000;
p = -1;
a = 1;
b = 1;

[MC_res, numerical_res] = genertate_testtable_rgig(p, a, b, sim);