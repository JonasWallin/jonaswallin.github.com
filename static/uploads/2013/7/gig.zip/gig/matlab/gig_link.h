#ifndef GIG_LINK_H
#define GIG_LINK_H

void sample_gig(double* ,double* ,double* ,double* ,int ,unsigned long* );


#endif
