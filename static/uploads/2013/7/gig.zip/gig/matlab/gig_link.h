#ifndef GIG_LINK_H
#define GIG_LINK_H

#ifdef __OPENMP
	#include <omp.h>
#endif
#include <iostream>

void sample_gig(double* ,double* ,double* ,double* ,int ,unsigned long* );


#endif
